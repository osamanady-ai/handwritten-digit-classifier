# Handwritten digit results

- Dataset: 1,797 real digit images, 64 pixel features, ten classes (0-9).
- Train/test: 1347/450, stratified split, seed 42.
- Chosen C: 10.0; training five-fold CV macro F1: 0.967.
- Held-out accuracy: 0.964; macro F1: 0.964.
- Majority baseline accuracy: 0.102; macro F1: 0.019.

This is a classic small benchmark of 8x8 grayscale digits, not a general OCR system.
The random split does not guarantee different writers in training and test sets, and performance
on photos, full documents, Arabic-script digits or a new writer is unverified. No such coverage
is claimed. Features remain inside a training-only scaling pipeline. Model selection uses
training CV; the held-out split is used for final evaluation only. Saved model uses training
rows only, matching these metrics. Error examples are intentionally shown, not hidden.

![Confusion matrix](evaluation.png)
![Held-out image examples](digit_examples.png)
